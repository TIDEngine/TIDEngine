$(function(){
  /**
   * Switching between slideshow and thumbnail views
   * we handle 2 different .on() events
   */
  $('#switch-slideshow').on('click', function(e){
    e.preventDefault();
    if(!$(this).hasClass('sel')) {
      $('ul.switcher li a').removeClass('sel');
      $(this).addClass('sel');
      
      // hide the thumbnails and display the slideshow
      $('#thumbnails').hide();
      $('#controls .slides').fadeIn(450);
      $('#mainimg').fadeIn(450, 'linear', function(){
        $('body').removeClass('thumbnail-view');
      });
    }
  });
  
  $('#switch-thumbnail').on('click', function(e){
    e.preventDefault();
    if(!$(this).hasClass('sel')) {
      $('ul.switcher li a').removeClass('sel');
      $(this).addClass('sel');
      
      // hide the slideshow and display thumbnails
      $('#mainimg').hide();
      $('#controls .slides').hide();
      $('#thumbnails').fadeIn(450, 'linear', function(){
        $('body').addClass('thumbnail-view');
      });
    }
  });
  
  /**
   * Slideshow pagination using arrow keys which hide during thumbnail display
   * we use 2 different .on() handlers for both keys
   */
  $('#keyleft').on('click', function(e){
    e.preventDefault();
    var currentimg = $('#thumbnails ul li.current');
    
    if(!currentimg.hasClass('first')) {
      // if any other image except the first, then navigate backwards
      var newimg = $(currentimg).prev();
      var newimgsrc = newimg.find('a').attr('href');
      
      currentimg.removeClass('current');
      newimg.addClass('current');
      $('#displayimg').attr('src', newimgsrc);
    }
  });
  
  $('#keyright').on('click', function(e){ 
    e.preventDefault();
    var currentimg = $('#thumbnails ul li.current');
    
    if(!currentimg.hasClass('last')) {
      // if any other image except the last, then navigate forwards
      var newimg = $(currentimg).next();
      var newimgsrc = newimg.find('a').attr('href');
      
      currentimg.removeClass('current');
      newimg.addClass('current');
      $('#displayimg').attr('src', newimgsrc);
    }
  });
  
  
  /**
   * Selecting any thumbnail image will update the current photo
   * and reset the UI back to slideshow view
   */
  $('#thumbnails ul li a').on('click', function(e){
    e.preventDefault();
    
    if(!$(this).parent().hasClass('current')) {
      // if we click anything except the currently selected image
      var newimgsrc = $(this).attr('href');
      $('#displayimg').attr('src', newimgsrc);
      
      $('#thumbnails ul li').removeClass('current');
      $(this).parent().addClass('current');
      
      // updating the slideshow view after choosing a photo
      $('ul.switcher li a').removeClass('sel');
      $('#switch-slideshow').addClass('sel');

      $('#thumbnails').hide();
      $('#controls .slides').fadeIn(450);
      $('#mainimg').fadeIn(450, 'linear', function(){
        $('body').removeClass('thumbnail-view');
      });      
    }
  });

});