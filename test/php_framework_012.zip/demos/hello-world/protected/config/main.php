<?php

return array(
    // application data
    'name'=>'Hello World',
    'version'=>'0.0.1',

    'defaultTemplate' => '',
	'defaultController' => 'Index',
    'defaultAction' => 'index',	
);