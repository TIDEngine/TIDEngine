<?php
/**
 * Locale data for 'en' - English
 */
return array (
  
    'Username' => 'Username',
    'Password' => 'Password',

);