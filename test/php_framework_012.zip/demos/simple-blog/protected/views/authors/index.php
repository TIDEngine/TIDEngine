<article>
	<h1><?php echo $mainHeader; ?></h1>
	<p><?php echo $mainText; ?></p>
</article>
