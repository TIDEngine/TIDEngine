<?php
    $this->_pageTitle = '404 Error';
?>

<h2><?php echo $header; ?></h2>

<p>
<?php echo CWidget::message('error', $text).'<br>'; ?>
</p>
