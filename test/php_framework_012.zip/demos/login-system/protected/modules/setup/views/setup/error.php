<?php
    $this->_activeMenu = $this->_controller.'/'.$this->_action;
?>

<p>
    <?php echo $errorMessage; ?>  
</p>