<?php
    $this->_activeMenu = $this->_controller.'/'.$this->_action;
?>

<h1>Welcome to Admin Panel!</h1>

<article>
    <p>
        The administrator panel is an integrated place to manage all your services,
        modules and features of this site. Use navigation menu links from the top to
        access required page.
    </p>
</article>