<?php
    $this->_pageTitle = '404 Error';
?>

<h2><?php echo $header; ?></h2>

<article>
<p><?php echo $text; ?></p>
</article>
