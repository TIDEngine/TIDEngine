<?php

header('location: ../index.html');
exit;

